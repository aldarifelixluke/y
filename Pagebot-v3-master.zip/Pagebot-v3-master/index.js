const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { handleMessage } = require('./handles/handle');
const { handlePostback } = require('./handles/Postback');
const config = require('./configure.json');
const utils = require('./utils');

const app = express();
app.use(bodyParser.json());

const colors = {
  blue: '\x1b[34m',
  red: '\x1b[31m',
  reset: '\x1b[0m'
};

const VERIFY_TOKEN = 'pagebot-v3';
app.use(express.static(path.join(__dirname, 'public')));

utils.loadMenuCommands();
utils.loadCommands();

app.get('/restart', (req, res) => {
  utils.restartServer();
  res.status(200).json({ status: true });
});

app.get('/reload-commands', (req, res) => {
  utils.loadMenuCommands();
  utils.loadCommands();
  res.status(200).json({ status: true });
});

app.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode && token) {
    if (mode === 'subscribe' && token === VERIFY_TOKEN) {
      utils.log('WEBHOOK_VERIFIED');
      res.status(200).send(challenge);
    } else {
      res.sendStatus(403);
    }
  }
});

app.post('/webhook', (req, res) => {
  const body = req.body;

  if (body.object === 'page') {
    body.entry.forEach(entry => {
      entry.messaging.forEach(event => {
        if (event.message) {
          handleMessage(event, config.pageAccessToken);
        } else if (event.postback) {
          handlePostback(event, config.pageAccessToken);
        }
      });
    });

    res.status(200).send('EVENT_RECEIVED');
  } else {
    res.sendStatus(404);
  }
});

function logTime() {
  const options = {
    timeZone: 'Asia/Jakarta',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  };

  const currentTime = new Date().toLocaleString('en-PH', options);
  const logMessage = `Current time: ${currentTime}\n`;
  utils.log(logMessage);
}

logTime();
setInterval(logTime, 60 * 60 * 1000);
module.exports = {
  commands: utils.commands
};
const hehe = require('./package.json');
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  utils.log(`${colors.red} Bot Owner: ${hehe.author}`);
});
