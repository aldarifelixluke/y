const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'help',
  description: 'Show available commands with descriptions',
  role: 1,
  category: "tools",
  author: 'Sli',
  execute( {
    senderId, args, sendMessage
  }) {
    const commandsDir = path.join(__dirname, '../cmds');
    const commandFiles = fs.readdirSync(commandsDir).filter(file => file.endsWith('.js'));

    const commands = commandFiles.map((file) => {
      const command = require(path.join(commandsDir, file));
      return {
        title: command.name,
        description: command.description,
        category: command.category,
      };
    });

    const categories = {};
    commands.forEach((command) => {
      if (!categories[command.category]) {
        categories[command.category] = [];
      }
      categories[command.category].push(command);
    });

    const emojis = {
      "tools": "🛠️",
      "music": "🎵",
      "ai": "🤖",
      "fun": "😄",
      "default": "❓"
    };

    let helpTextMessage = `📖 𝗛𝗲𝗹𝗽 𝗠𝗲𝗻𝘂: [ ${commands.length} ] `;
    Object.keys(categories).forEach((category, index) => {
      const emoji = emojis[category] || emojis["default"];
      helpTextMessage += `\n\n${emoji} | **${category.toUpperCase()}**:\n`;
      helpTextMessage += categories[category].map((cmd) => `→ ${cmd.title}`).join('\n');
    });
    helpTextMessage += `\n\n🛠 𝗧𝗶𝗽: Use help <command> to view command info.`;

    sendMessage(senderId,
      {
        text: helpTextMessage
      });
  }
};