const axios = require('axios');

module.exports = {
  name: 'bertai',
  description: 'Bert AI',
  role: 1,
  category: "ai",
  author: 'Sli',

  async execute({ senderId, args, sendMessage }) {
    const prompt = args.join(' ').trim();

    
    if (!prompt) {
      return sendMessage(senderId, {
        text: 'Hello! I am Bert Ai, how can I help you?'
      });
    }

    const apiUrl = `https://kaiz-apis.gleeze.com/api/bert-ai?q=${encodeURIComponent(prompt)}&apikey=99b89d67-177a-4ef5-964a-fb449e5c9973`;

    try {
      const response = await axios.get(apiUrl);
      const reply = response.data.response;

      if (reply) {
        
        const formattedResponse = `💻📦 *Bert AI Response** :\n\n${reply}`;
        
        
        const maxLength = 2000;

        
        if (formattedResponse.length > maxLength) {
          const chunks = [];
          let remainingText = formattedResponse;

          while (remainingText.length > 0) {
            chunks.push(remainingText.substring(0, maxLength));
            remainingText = remainingText.substring(maxLength);
          }

          
          for (const chunk of chunks) {
            await sendMessage(senderId, { text: chunk });
          }
        } else {
          
          await sendMessage(senderId, { text: formattedResponse });
        }
      } else {
        
        await sendMessage(senderId, { text: 'Sorry, there was an error processing your request.' });
      }
    } catch (error) {
      console.error('Error calling Blackbox API:', error);

      
      await sendMessage(senderId, { text: 'Sorry, there was an error processing your request.' });
    }
  }
};
