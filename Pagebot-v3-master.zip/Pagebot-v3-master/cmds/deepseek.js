const axios = require('axios');

module.exports = {
  name: 'deepseek',
  description: 'Deepseek AI',
  role: 1,
  category: "ai",
  author: 'Sli',

  async execute({ senderId, args, sendMessage }) {
    const prompt = args.join(' ').trim();

    
    if (!prompt) {
      return sendMessage(senderId, {
        text: 'Hello! I am Deepseek Ai, how can I help you?'
      });
    }

    const apiUrl = `https://api.ryzumi.vip/api/ai/deepseek?text=${encodeURIComponent(prompt)}&session=${senderId}`;

    try {
      const response = await axios.get(apiUrl);
      const reply = response.data.answer;

      if (reply) {
        
        const formattedResponse = `💻📦 **Deepseek Response** :\n\n${reply}`;
        
        
        const maxLength = 2000;

        
        if (formattedResponse.length > maxLength) {
          const chunks = [];
          let remainingText = formattedResponse;

          while (remainingText.length > 0) {
            chunks.push(remainingText.substring(0, maxLength));
            remainingText = remainingText.substring(maxLength);
          }

          
          for (const chunk of chunks) {
            await sendMessage(senderId, { text: chunk });
          }
        } else {
          
          await sendMessage(senderId, { text: formattedResponse });
        }
      } else {
        
        await sendMessage(senderId, { text: 'Sorry, there was an error processing your request.' });
      }
    } catch (error) {
      console.error('Error calling Blackbox API:', error);

      
      await sendMessage(senderId, { text: 'Sorry, there was an error processing your request.' });
    }
  }
};
