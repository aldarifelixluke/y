const axios = require('axios');

module.exports = {
  name: 'chords',
  description: 'Fetch song chords',
  author: 'Sli',
  category: "search",
  role: 1,

  async execute({ senderId, args, sendMessage }) {
    const query = args.join(' ');
    try {
      const apiUrl = `https://api.ryzumi.vip/api/search/chord?query=${encodeURIComponent(query)}`;
      const response = await axios.get(apiUrl);
      const result = response.data.chord;

      if (result && result.chord) {
        const chordsMessage = `${result.chord}`;

        
        await sendResponseInChunks(senderId, chordsMessage);

      } else {
        console.error('Error: No chords found in the response.');
        await sendMessage(senderId, { text: 'Sorry, no chords were found for your query.' });
      }
    } catch (error) {
      console.error('Error calling Chords API:', error);
      await sendMessage(senderId, { text: 'Sorry, there was an error processing your request.' });
    }
  }
};


async function sendResponseInChunks(senderId, text) {
  const maxMessageLength = 2000;
  if (text.length > maxMessageLength) {
    const messages = splitMessageIntoChunks(text, maxMessageLength);
    for (const message of messages) {
      await sendMessage(senderId, { text: message });
    }
  } else {
    await sendMessage(senderId, { text });
  }
}


function splitMessageIntoChunks(message, chunkSize) {
  const chunks = [];
  let chunk = '';
  const words = message.split(' ');

  for (const word of words) {
    if ((chunk + word).length > chunkSize) {
      chunks.push(chunk.trim());
      chunk = '';
    }
    chunk += `${word} `;
  }

  if (chunk) {
    chunks.push(chunk.trim());
  }

  return chunks;
}
