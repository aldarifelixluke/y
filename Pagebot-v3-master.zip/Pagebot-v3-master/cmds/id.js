
module.exports = {
  name: 'id',
  description: 'Show sender ID',
  author: 'Sli',
  category: "tools",
  role: 1,
  async execute({ senderId, args, sendMessage }) {
 
    const response = `senderId: ${senderId}`;
    

    try {
      await sendMessage(senderId, { text: response });
    } catch (error) {
      console.error('Error sending message:', error);
    }
  }
};
