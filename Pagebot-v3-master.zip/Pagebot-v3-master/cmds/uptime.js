const os = require('os');
const moment = require('moment-timezone');

function getUptime() {
  const currentTime = new Date().getTime();
  const startTime = currentTime - (os.uptime() * 1000);
  const uptime = currentTime - startTime;
  const years = Math.floor(uptime / (365 * 24 * 60 * 60 * 1000));
  const months = Math.floor((uptime % (365 * 24 * 60 * 60 * 1000)) / (30 * 24 * 60 * 60 * 1000));
  const days = Math.floor((uptime % (30 * 24 * 60 * 60 * 1000)) / (24 * 60 * 60 * 1000));
  const hours = Math.floor((uptime % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
  const minutes = Math.floor((uptime % (60 * 60 * 1000)) / (60 * 1000));
  const seconds = Math.floor((uptime % (60 * 1000)) / 1000);

  const date = moment().tz('Asia/Jakarta').format('M/D/YYYY, HH:mm:ss');

  let uptimeString = `📡 **Uptime Status**\n`
  uptimeString += `─────────────\n`
  uptimeString += `${seconds} __Second(s)__\n`
  uptimeString += `${minutes} __Minute(s)__\n`
  uptimeString += `${hours} __Hour(s)__\n`
  uptimeString += `${days} __Day(s)__\n`
  uptimeString += `${months} __Month(s)__\n`
  uptimeString += `${years} __Year(s)__\n`;
  uptimeString += `─────────────\n`;
  uptimeString += `🕒 **Asia/Jakarta**: ${date} (GMT +7)`;

  return uptimeString;
}

module.exports = {
  name: 'uptime',
  description: 'Show uptime server',
  author: 'Sli',
  role: 1,
  async execute( {
    senderId, args, sendMessage
  }) {

    const response = getUptime();

    try {
      await sendMessage(senderId, {
        text: response
      });
    } catch (error) {
      console.error('Error sending message:', error);
    }
  }
};