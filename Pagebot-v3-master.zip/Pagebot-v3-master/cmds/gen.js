const axios = require('axios');

module.exports = {
  name: 'gen',
  description: 'Generate an image based on a prompt.',
  role: 1,
  author: 'Sli',
  
  async execute({ senderId, args, sendMessage }) {
    if (!args || args.length === 0) {
      await sendMessage(senderId, {
        text: 'Please provide a prompt.\n\nUsage:\nExample: gen cat'
      });
      return;
    }

    const prompt = args.join(' ');
    const apiUrl = `https://api.ryzumi.vip/api/ai/v2/text2img?prompt=${encodeURIComponent(prompt)}&model=turbo&enhance=true`;

    try {
      await sendMessage(senderId, {
        attachment: {
          type: 'image',
          payload: {
            url: apiUrl
          }
        }
      });

    } catch (error) {
      console.error('Error generating image:', error);
      await sendMessage(senderId, {
        text: 'An error occurred while generating the image. Please try again later.'
      });
    }
  }
};
    
