const request = require('request');
const axios = require('axios');
const utils = require("../utils");

const fonts = {
  bold: {
    a: '𝗮',
    b: '𝗯',
    c: '𝗰',
    d: '𝗱',
    e: '𝗲',
    f: '𝗳',
    g: '𝗴',
    h: '𝗵',
    i: '𝗶',
    j: '𝗷',
    k: '𝗸',
    l: '𝗹',
    m: '𝗺',
    n: '𝗻',
    o: '𝗼',
    p: '𝗽',
    q: '𝗾',
    r: '𝗿',
    s: '𝘀',
    t: '𝘁',
    u: '𝘂',
    v: '𝘃',
    w: '𝘄',
    x: '𝘅',
    y: '𝘆',
    z: '𝘇',
    A: '𝗔',
    B: '𝗕',
    C: '𝗖',
    D: '𝗗',
    E: '𝗘',
    F: '𝗙',
    G: '𝗚',
    H: '𝗛',
    I: '𝗜',
    J: '𝗝',
    K: '𝗞',
    L: '𝗟',
    M: '𝗠',
    N: '𝗡',
    O: '𝗢',
    P: '𝗣',
    Q: '𝗤',
    R: '𝗥',
    S: '𝗦',
    T: '𝗧',
    U: '𝗨',
    V: '𝗩',
    W: '𝗪',
    X: '𝗫',
    Y: '𝗬',
    Z: '𝗭'
  },
  italic: {
    a: '𝐚',
    b: '𝐛',
    c: '𝐜',
    d: '𝐝',
    e: '𝐞',
    f: '𝐟',
    g: '𝐠',
    h: '𝐡',
    i: '𝐢',
    j: '𝐣',
    k: '𝐤',
    l: '𝐥',
    m: '𝐦',
    n: '𝐧',
    o: '𝐨',
    p: '𝐩',
    q: '𝐪',
    r: '𝐫',
    s: '𝐬',
    t: '𝐭',
    u: '𝐮',
    v: '𝐯',
    w: '𝐰',
    x: '𝐱',
    y: '𝐲',
    z: '𝐳',
    A: '𝐀',
    B: '𝐁',
    C: '𝐂',
    D: '𝐃',
    E: '𝐄',
    F: '𝐅',
    G: '𝐆',
    H: '𝐇',
    I: '𝐈',
    J: '𝐉',
    K: '𝐊',
    L: '𝐋',
    M: '𝐌',
    N: '𝐍',
    O: '𝐎',
    P: '𝐏',
    Q: '𝐐',
    R: '𝐑',
    S: '𝐒',
    T: '𝐓',
    U: '𝐔',
    V: '𝐕',
    W: '𝐖',
    X: '𝐗',
    Y: '𝐘',
    Z: '𝐙'
  },
  monospace: {
    a: '𝚊',
    b: '𝚋',
    c: '𝚌',
    d: '𝚍',
    e: '𝚎',
    f: '𝚏',
    g: '𝚐',
    h: '𝚑',
    i: '𝚒',
    j: '𝚓',
    k: '𝚔',
    l: '𝚕',
    m: '𝚖',
    n: '𝚗',
    o: '𝚘',
    p: '𝚙',
    q: '𝚚',
    r: '𝚛',
    s: '𝚜',
    t: '𝚝',
    u: '𝚞',
    v: '𝚟',
    w: '𝚠',
    x: '𝚡',
    y: '𝚢',
    z: '𝚣',
    A: '𝙰',
    B: '𝙱',
    C: '𝙲',
    D: '𝙳',
    E: '𝙴',
    F: '𝙵',
    G: '𝙶',
    H: '𝙷',
    I: '𝙸',
    J: '𝙹',
    K: '𝙺',
    L: '𝙻',
    M: '𝙼',
    N: '𝙽',
    O: '𝙾',
    P: '𝙿',
    Q: '𝚀',
    R: '𝚁',
    S: '𝚂',
    T: '𝚃',
    U: '𝚄',
    V: '𝚅',
    W: '𝚆',
    X: '𝚇',
    Y: '𝚈',
    Z: '𝚉'
  },
  strikethrough: {
    a: 'a̶',
    b: 'b̶',
    c: 'c̶',
    d: 'd̶',
    e: 'e̶',
    f: 'f̶',
    g: 'g̶',
    h: 'h̶',
    i: 'i̶',
    j: 'j̶',
    k: 'k̶',
    l: 'l̶',
    m: 'm̶',
    n: 'n̶',
    o: 'o̶',
    p: 'p̶',
    q: 'q̶',
    r: 'r̶',
    s: 's̶',
    t: 't̶',
    u: 'u̶',
    v: 'v̶',
    w: 'w̶',
    x: 'x̶',
    y: 'y̶',
    z: 'z̶',
    A: 'A̶',
    B: 'B̶',
    C: 'C̶',
    D: 'D̶',
    E: 'E̶',
    F: 'F̶',
    G: 'G̶',
    H: 'H̶',
    I: 'I̶',
    J: 'J̶',
    K: 'K̶',
    L: 'L̶',
    M: 'M̶',
    N: 'N̶',
    O: 'O̶',
    P: 'P̶',
    Q: 'Q̶',
    R: 'R̶',
    S: 'S̶',
    T: 'T̶',
    U: 'U̶',
    V: 'V̶',
    W: 'W̶',
    X: 'X̶',
    Y: 'Y̶',
    Z: 'Z̶'
  }
};

function convertTextToStyle(text, style) {
  const fontMap = fonts[style];
  if (!fontMap) return text;
  return Array.from(text).map(char => fontMap[char] || char).join('');
}

function parseAndConvert(input) {
  const patterns = [{
    regex: /\*\*(.*?)\*\*/g,
    style: 'bold'
  },
    // **...**
    {
      regex: /__(.*?)__/g,
      style: 'italic'
    },
    // __...__
    {
      regex: /``(.*?)``/g,
      style: 'monospace'
    },
    // ``...``
    {
      regex: /~~(.*?)~~/g,
      style: 'strikethrough'
    } // ~~...~~
  ];

  let output = input;
  patterns.forEach(({
    regex, style
  }) => {
    output = output.replace(regex, (_, group) => convertTextToStyle(group, style));
  });

  return output;
}

async function typingIndicator(senderId, pageAccessToken) {
  if (!senderId) {
    utils.log('Invalid senderId for typing indicator.');
    return;
  }

  try {
    await axios.post(`https://graph.facebook.com/v13.0/me/messages`, {
      recipient: {
        id: senderId
      },
      sender_action: 'typing_on',
    }, {
      params: {
        access_token: pageAccessToken
      },
    });
  } catch (error) {
    utils.log('Error sending typing indicator:', error.response?.data || error.message);
  }
}

function sendMessage(senderId, message) {
  if (!message || (!message.text && !message.attachment)) {
    utils.log("Message must contain 'text' or 'attachment'.");
    return;
  }
  
  const { pageAccessToken } = require('../configure.json');
  
  if (message?.text) {
    message.text = parseAndConvert(message.text);
  }

  typingIndicator(senderId, pageAccessToken);

  const requestData = {
    recipient: {
      id: senderId
    },
    message,
  };

  request.post(
    {
      url: `https://graph.facebook.com/v13.0/me/messages`,
      qs: {
        access_token: pageAccessToken
      },
      json: requestData,
    },
    (error, response, body) => {
      if (error) {
        utils.log('Error sending message:', error);
      } else {
        utils.log('Message sent successfully:', body);
      }
    }
  );
}

module.exports = {
  sendMessage
};