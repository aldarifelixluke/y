const fs = require('fs');
const path = require('path');
const axios = require('axios');
const {
  sendMessage
} = require('./message');
const config = require('../configure.json');
const utils = require("../utils");
const { commands } = require("../index");

async function handleMessage(event, pageAccessToken) {
  if (!event?.sender?.id) {
    utils.log('Invalid event object: Missing sender ID.');
    return;
  }

  const senderId = event.sender.id;

  if (event.message?.text) {
    const messageText = event.message.text.trim();
    utils.log(`Received message: ${messageText}`);

    const prefixes = config.prefixes || [];

    let commandName;
    let args;

    if (prefixes.length > 0) {
      const prefix = prefixes.find((prefix) => messageText.startsWith(prefix));
      if (prefix) {
        const messageWithoutPrefix = messageText.slice(prefix.length).trim();
        const words = messageWithoutPrefix.split(' ');
        commandName = words.shift().toLowerCase();
        args = words;
      } else {
        // Jika prefix tidak ditemukan, gunakan pesan sebagai pesan default
        commandName = 'default';
        args = [messageText];
      }
    } else {
      // Jika prefix tidak ada, verifikasi nama perintah langsung
      const words = messageText.split(' ');
      commandName = words.shift().toLowerCase();
      args = words;

      // Jika perintah tidak ditemukan, gunakan pesan sebagai pesan default
      if (!commands.has(commandName)) {
        commandName = 'default';
        args = [messageText];
      }
    }

    utils.log(`Parsed command: ${commandName} with arguments: ${args}`);

    if (commandName === 'default') {
      const defaultCommand = commands.get('ai');
      if (defaultCommand) {
        try {
          utils.saveUsers(senderId);
          utils.saveRank(commandName);
          await defaultCommand.execute({ senderId, args, pageAccessToken, event});
        } catch (error) {
          utils.log('Error executing default "ai" command:', error);
          sendMessage(senderId, {
            text: 'There was an error processing your request.'
          });
        }
      } else {
        sendMessage(senderId, {
          text: "Sorry, I couldn't understand that. Please try again."
        });
      }
    } else {
      const command = commands.get(commandName);
      if (command) {
        if (command.role === 0 && !config.adminId.includes(senderId)) {
          sendMessage(senderId, {
            text: 'You are not authorized to use this command.'
          });
          return;
        }
        try {
          let imageUrl = '';
          if (event.message?.reply_to?.mid) {
            try {
              imageUrl = await getAttachments(event.message.reply_to.mid, pageAccessToken);
            } catch (error) {
              utils.log("Failed to get attachment:", error);
              imageUrl = '';
            }
          } else if (event.message?.attachments?.[0]?.type === 'image') {
            imageUrl = event.message.attachments[0].payload.url;
          }
          utils.saveUsers(senderId);
          utils.saveRank(commandName);
          await command.execute({ senderId, args, pageAccessToken, event, imageUrl, config, sendMessage});
        } catch (error) {
          utils.log(`Error executing command "${commandName}":`, error);
          sendMessage(senderId, {
            text: 'There was an error executing that command.'
          });
        }
      }
    }
  } else {
    utils.log('Message or text is not present in the event.');
  }
}


async function getAttachments(mid, pageAccessToken) {
  if (!mid) {
    utils.log("No message ID provided for getAttachments.");
    throw new Error("No message ID provided.");
  }

  try {
    const {
      data
    } = await axios.get(`https://graph.facebook.com/v21.0/${mid}/attachments`, {
        params: {
          access_token: pageAccessToken
        }
      });

    if (data?.data?.length > 0 && data.data[0].image_data) {
      return data.data[0].image_data.url;
    } else {
      utils.log("No image found in the replied message.");
      throw new Error("No image found in the replied message.");
    }
  } catch (error) {
    utils.log("Error fetching attachments:", error.response?.data || error.message);
    throw new Error("Failed to fetch attachments.");
  }
}

module.exports = {
  handleMessage
};