const cron = require('node-cron');
const fs = require('fs');
const path = require('path');
const { sendMessage } = require('./message');

const usersFile = path.join(__dirname, '../data/users.json');

const getUsers = () => {
  try {
    const users = JSON.parse(fs.readFileSync(usersFile, 'utf8'));
    return Object.keys(users).filter((id) => users[id].autosend === true).map((id) => id);
  } catch (error) {
    console.error('Error reading users file:', error);
    return [];
  }
};

const sendGreeting = (greeting) => {
  const ids = getUsers();
  ids.forEach((id) => {
    sendMessage(id, { text: `📢 **Announcement**:\n\n${greeting}` });
  });
};

cron.schedule('0 6 * * *', () => {
  sendGreeting('Good morning!');
});

cron.schedule('0 12 * * *', () => {
  sendGreeting('Good afternoon!');
});

cron.schedule('0 18 * * *', () => {
  sendGreeting('Good evening!');
});

cron.schedule('0 22 * * *', () => {
  sendGreeting('Good night!');
});

cron.schedule('0 23 * * *', () => {
  sendGreeting('Have a good sleep!');
});