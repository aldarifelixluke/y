const fs = require('fs');
const path = require('path');
const moment = require('moment');
const childProcess = require('child_process');
const usersFile = path.join(__dirname, 'data/users.json');
const rankFile = path.join(__dirname, 'data/rank.json');
const logFile = path.join(__dirname, 'data/logs.json');
const commands = new Map();

function log(message) {
  const timestamp = moment().format('DD/MM/YY, hh:mm:ss A');
  const logMessage = `[${timestamp}] ${message}`;
  console.log(logMessage);

  try {
    let logs = [];
    try {
      logs = JSON.parse(fs.readFileSync(logFile, 'utf8'));
    } catch (error) {
    }
    logs.push(logMessage);
    fs.writeFileSync(logFile, JSON.stringify(logs, null, 2));
    console.log(message);
  } catch (error) {
    console.error('Error writing log:', error);
  }
}

function saveUsers(senderId) {
  const users = JSON.parse(fs.readFileSync(usersFile, 'utf8') || '{}');

  if (!users[senderId]) {
    users[senderId] = {
      id: senderId,
      autosend: true,
      messageCount: 0,
    };
  }

  users[senderId].messageCount++;

  fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
}

function saveRank(commandName) {
  const rank = JSON.parse(fs.readFileSync(rankFile, 'utf8') || '{}');

  if (commandName === 'default') {
    commandName = 'ai';
  }

  if (!rank[commandName]) {
    rank[commandName] = {
      usageCount: 0,
    };
  }

  rank[commandName].usageCount++;

  fs.writeFileSync(rankFile, JSON.stringify(rank, null, 2));
}

const restartServer = () => {
  const logFile = path.join(__dirname, 'data/logs.json');
  fs.writeFileSync(logFile, JSON.stringify([]));

  console.log('Server akan di-restart');
  process.exit(1);
};

const loadMenuCommands = async () => {
  try {
    const commandsDir = path.join(__dirname, 'cmds');
    const commandFiles = fs.readdirSync(commandsDir).filter(file => file.endsWith('.js'));

    const commandsList = commandFiles.map(file => {
      const command = require(path.join(commandsDir, file));
      return { name: command.name, description: command.description || 'No description available' };
    });

    const loadCmd = await axios.post(`https://graph.facebook.com/v21.0/me/messenger_profile?access_token=${config.pageAccessToken}`, {
      commands: [
        {
          locale: "default",
          commands: commandsList
        }
      ]
    }, {
      headers: {
        "Content-Type": "application/json"
      }
    });

    if (loadCmd.data.result === "success") {
      this.log("Commands loaded!");
    } else {
      this.log("Failed to load commands");
    }
  } catch (error) {
    this.log('Error loading commands:', error);
  }
};

const loadCommands = () => {
  commands.clear();
  const commandFiles = fs.readdirSync(path.join(__dirname, 'cmds')).filter(file => file.endsWith('.js'));
  for (const file of commandFiles) {
    delete require.cache[require.resolve(`../cmds/${file}`)];
    const command = require(`cmds/${file}`);
    commands.set(command.name.toLowerCase(), command);
    this.log(`Loaded command: ${command.name}`);
  }
};

module.exports = {
  log,
  saveUsers,
  saveRank,
  commands,
  loadMenuCommands,
  loadCommands,
}